package com.example.term_project;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RecomActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recom_layout);

//        TextView text1=(TextView)findViewById(R.id.text1);
//        TextView text2=(TextView)findViewById(R.id.text2);
//        TextView text3=(TextView)findViewById(R.id.text3);
//
//        SharedPreferences sf=getSharedPreferences("sFile",MODE_PRIVATE);
//
//        final String name=sf.getString("user_name","");
//        final String phone=sf.getString("user_phone","");
//        final String email=sf.getString("user_email","");
//
//        text1.setText("사용자 이름 :"+name);
//        text2.setText("사용자 이름 :"+phone);
//        text3.setText("선호:"+InterestActivity.interest[0]);


    }
}
